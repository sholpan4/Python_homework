
#python3 -m venv .venv
#python3 -m pip install PyQt5
#$Env:QT_QPA_PLATFORM_PLUGIN_PATH = "venv/lib/site-packages/PyQt6/plugins/platforms"
